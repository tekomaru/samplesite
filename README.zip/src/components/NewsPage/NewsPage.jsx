


export default function NewsPage() {
    return(
        <div className={styles.NewsList_wrapper}>
            <div className={styles.PageTitle_wrapper}>
                <h2 className={styles.PageTitle_transparent}>NEWS</h2>
            </div>
            
        </div>
        )
    }